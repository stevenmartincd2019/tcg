package com.fus.tcg.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.fus.tcg.R;

public class MainActivity extends AppCompatActivity {





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle(R.string.incio);
        welcomeInformation();
    }

    /**
     * Set welcome information per user
     */
    private void welcomeInformation() {
        String welcome = getString(R.string.welcome);
        //String email = user.getEmail();
        String email = "admin";
        TextView userEmail = findViewById(R.id.textView2);
    }

    /**
     * Method for Logout
     *
     * @param view Parameter for assigning each button to onClick
     */
    public void logout(View view) {
        startActivity(new Intent(getApplicationContext(), AuthActivity.class));
        finish();
    }

    /**
     * Method for going to the activity of creating a new legalization
     *
     * @param view Parameter for assigning each button to onClick
     */
    public void nuevaLegalizacion(View view) {
        Intent intent = new Intent(this, FormActivity.class);
        startActivity(intent);
    }

    /**
     * Method to go to the activity to see the legalizations created by each user
     *
     * @param view Parameter for assigning each button to onClick
     */
    public void misLegalizaciones(View view) {
        Intent intent = new Intent(this, HistoryActivity.class);
        startActivity(intent);
    }

}
