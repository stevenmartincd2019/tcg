package com.fus.tcg.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.fus.tcg.R;

/**
 * Class responsible for confirming successful submission of information
 */
public class ConfirmActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_confirm);
        returnMain();
    }

    /**
     * Actions to be performed when pressing the button back to the beginning
     */
    private void returnMain() {
        Button returnMain = findViewById(R.id.returnMain);
        returnMain.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sendMainActivity();
            }
        });
    }

    /**
     * Actions to perform when pressing the back button
     */
    @Override
    public void onBackPressed() {
        sendMainActivity();
    }

    /**
     * Method that sends to MainActivity
     */
    private void sendMainActivity() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}
