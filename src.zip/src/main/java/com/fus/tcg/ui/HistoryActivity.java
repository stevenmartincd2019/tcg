package com.fus.tcg.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.fus.tcg.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Class in charge of displaying the information loaded in the database
 */
public class HistoryActivity extends AppCompatActivity {


    EditText campoConsecutivo;
    TextView txFecha,txCiudad, txDescripcion, txEstado;
    Button btConsultar;

    RequestQueue requestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mis_legalizaciones);
        campoConsecutivo= (EditText) findViewById(R.id.Consecutivo);
        txCiudad= (TextView) findViewById(R.id.txCiudad);
        txFecha= (TextView) findViewById(R.id.txFecha);
        txDescripcion= (TextView) findViewById(R.id.txDescripcion);
        txEstado= (TextView) findViewById(R.id.txEstado);
        btConsultar= (Button) findViewById(R.id.btConsultar);
        btConsultar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                consulta("http://192.168.0.11/CSG/misLegalizaciones.php?consecutivo="
                        +campoConsecutivo.getText().toString());
                txEstado.setText("pendiete");
            }
        });
    }
   private void consulta (String URL){
       JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
           @Override
           public void onResponse(JSONArray response) {
               JSONObject jsonObject = null;
               for (int i=0;i<response.length();i++){
                   try {
                       jsonObject =response.getJSONObject(i);
                       txFecha.setText(jsonObject.getString("fecha_gasto"));
                       txCiudad.setText(jsonObject.getString("ciudad"));
                       txDescripcion.setText(jsonObject.getString("descripcion"));
                   } catch (JSONException e){
                       Toast.makeText(getApplicationContext(), e.getMessage(),Toast.LENGTH_SHORT).show();

                   }
               }
           }
       }, new Response.ErrorListener() {
           @Override
           public void onErrorResponse(VolleyError error) {
               Toast.makeText(getApplicationContext(), "No existe legalizacion",Toast.LENGTH_SHORT).show();

           }

   });

       requestQueue = Volley.newRequestQueue(this);
       requestQueue.add(jsonArrayRequest);
   }
}


