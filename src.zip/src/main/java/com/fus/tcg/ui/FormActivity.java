package com.fus.tcg.ui;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.fus.tcg.R;
import com.fus.tcg.ui.fragment.DatePickerFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Class of the Form activity.
 */
public class FormActivity extends AppCompatActivity {
    public static final String ENVIAR_CONSECUTIVO ="consecutivo";

    private TextInputEditText txNitFm;

    private TextInputEditText txNombreProveedorFm;

    private TextInputEditText txTelefonoFm;

    private TextInputEditText txCiudadFm;

    private TextInputEditText txTipoComprobanteFm;

    private TextInputEditText fecha;

    private TextInputEditText txConsecutivoFm;

    private TextInputEditText txValorFm;

    private TextInputEditText txDescripcionFm;

    private TextInputEditText txMotivoFm;

    private TextInputLayout consecutivo;

    private TextInputLayout fechaGasto;

    private TextInputLayout valor;

    private TextInputLayout nit;

    private TextInputLayout nombreProveedor;

    private TextInputLayout telefonoProveedor;

    private TextInputLayout ciudad;

    private TextInputLayout tipoComprobante;

    private TextInputLayout motivo;

    private TextInputLayout descipcion;

    private MaterialButton Btnext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        setTitle(getString(R.string.title_activity_formulario));

        informationForm();
        datePicker();


        resetTextInputErrorsOnTextChanged(consecutivo, fechaGasto, valor, nit, nombreProveedor, telefonoProveedor, ciudad, tipoComprobante, motivo, descipcion);

        Btnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviar("http://192.168.0.11/CSG/formulario.php");
                Intent i = new Intent (FormActivity.this, SendActivity.class);
                i.putExtra("consecutivo", txConsecutivoFm.getText().toString());

                startActivity(i);
            }
        });
    }


    private void enviar(String URL) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Enviado", Toast.LENGTH_SHORT).show();
            }



        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(FormActivity.this, error.toString(), Toast.LENGTH_SHORT).show();

            }
        }){
            @Override
            protected Map<String, String> getParams () throws AuthFailureError {
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("Nit",txNitFm.getText().toString());
                parametros.put("Proveedor",txNombreProveedorFm.getText().toString());
                parametros.put("Ciudad",txCiudadFm.getText().toString());
                parametros.put("TipoComprobante",txTipoComprobanteFm.getText().toString());
                parametros.put("FechaGasto",fecha.getText().toString());
                parametros.put("Consecutivo",txConsecutivoFm.getText().toString());
                parametros.put("Valor",txValorFm.getText().toString());
                parametros.put("Descripcion",txDescripcionFm.getText().toString());
                parametros.put("Motivo",txMotivoFm.getText().toString());
                parametros.put("Telefono",txTelefonoFm.getText().toString());

                return parametros;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    /**
     * Method for assigning field id and calling showDatePickerDialog method
     */
    private void datePicker() {
        fecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.fecha:
                        showDatePickerDialog();
                        break;
                }
            }
        });
    }

    /**
     * DatePicker fragment call and date format
     */


    private void showDatePickerDialog() {
        DatePickerFragment newFragment = DatePickerFragment.newInstance(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                String dia;
                String mes;

                if (day < 10) {
                    dia = "0" + day;
                } else {
                    dia = Integer.toString(day);
                }

                if (month < 10) {
                    mes = "0" + (month + 1);
                } else {
                    mes = Integer.toString((month + 1));
                }

                final String selectedDate = dia + "/" + mes + "/" + year;
                fecha.setText(selectedDate);
            }
        });
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }



    /**
     * Method for validating that no field is empty
     *
     * @param textInputLayouts fields will be checked whether they are empty or not
     * @return returns true if any field is empty and false when no field is empty
     */
    private boolean fieldValidator(TextInputLayout... textInputLayouts) {
        for (final TextInputLayout inputLayout : textInputLayouts) {
            final TextInputEditText editText = (TextInputEditText) inputLayout.getEditText();
            String text = Objects.requireNonNull(editText.getText()).toString();
            if (TextUtils.isEmpty(text)) {
                inputLayout.setError(getString(R.string.campo_requerido));
                return true;
            }
        }
        return false;
    }

    /**
     * Method for clearing information from fields
     *
     * @param view button assignment
     */
    public void cleanForm(View view) {
        txNitFm.setText(null);
        txNombreProveedorFm.setText(null);
        txCiudadFm.setText(null);
        txTelefonoFm.setText(null);
        txTipoComprobanteFm.setText(null);
        fecha.setText(null);
        txConsecutivoFm.setText(null);
        txValorFm.setText(null);
        txDescripcionFm.setText(null);
        txMotivoFm.setText(null);
    }

    /**
     * Method for assigning variables
     */
    private void informationForm() {
        FloatingActionButton btBorrar = findViewById(R.id.clean);
        btBorrar.setColorFilter(Color.WHITE);
        txNitFm = findViewById(R.id.nit);
        txNombreProveedorFm = findViewById(R.id.nombreProveedor);
        txTelefonoFm = findViewById(R.id.telefono);
        txTipoComprobanteFm = findViewById(R.id.tipoComprobante);
        fecha = findViewById(R.id.fecha);
        txConsecutivoFm = findViewById(R.id.TxConsecutivoFm);
        txValorFm = findViewById(R.id.valor);
        txDescripcionFm = findViewById(R.id.descripcion);
        txMotivoFm = findViewById(R.id.TxMotivoFm);
        txCiudadFm = findViewById(R.id.TxCiudadFm);
        Btnext = findViewById(R.id.next);

        consecutivo = findViewById(R.id.outlinedConsecutivo);
        fechaGasto = findViewById(R.id.outlineFecha);
        valor = findViewById(R.id.outlineValor);
        nit = findViewById(R.id.outlinedNit);
        nombreProveedor = findViewById(R.id.outlinedNombreProveedor);
        telefonoProveedor = findViewById(R.id.outlineTelefono);
        ciudad = findViewById(R.id.outlineCiudad);
        tipoComprobante = findViewById(R.id.outlineTipoComprobante);
        motivo = findViewById(R.id.outlineMotivo);
        descipcion = findViewById(R.id.outlineDescipcion);
    }
    public void enviarMensaje(View view) {
        Intent intent = new Intent(this, SendActivity.class);
        TextInputEditText consecutivo = (TextInputEditText) findViewById(R.id.TxConsecutivoFm);
        String consecutivo1 = consecutivo.getText().toString();
        intent.putExtra(ENVIAR_CONSECUTIVO, consecutivo1);
        startActivity(intent);
    }
    /**
     * Method for handling error messages in the fields
     *
     * @param textInputLayouts this parameter will refer to the fields you want to manipulate errors
     */
    public void resetTextInputErrorsOnTextChanged(TextInputLayout... textInputLayouts) {
        for (final TextInputLayout inputLayout : textInputLayouts) {
            final TextInputEditText editText = (TextInputEditText) inputLayout.getEditText();
            if (editText != null) {
                editText.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after) {

                    }

                    @Override
                    public void onTextChanged(final CharSequence s, final int start, final int before, final int count) {

                    }

                    @Override
                    public void afterTextChanged(final Editable s) {
                        if (inputLayout.getError() != null) inputLayout.setError(null);
                    }
                });

                editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (!hasFocus) {
                            if (!TextUtils.isEmpty(editText.getText())) {
                                inputLayout.setError(null);
                            } else {
                                inputLayout.setError(getString(R.string.campo_requerido));
                            }
                        }
                    }
                });
            }
        }
    }


}
