package com.fus.tcg.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.fus.tcg.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.HashMap;
import java.util.Map;



/**
 * Class for application authentication
 */
public class AuthActivity extends AppCompatActivity {

    private EditText mPassword;

    private TextInputEditText mCorreo;

    private MaterialButton logIn;

    private TextView olvidarTextLink;

    private TextInputLayout email;

    private TextInputLayout clave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        assignmentVariables();
        //logIn();
        //restoredAccount();
        //verifyAuthentication();
        resetTextInputErrorsOnTextChanged(email, clave);

        logIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyAuthentication("http://192.168.0.11/CSG/index.php");
            }
        });
    }

    /**
     * Method for assigning variables
     */
    private void assignmentVariables() {
        mCorreo = findViewById(R.id.email);
        mPassword = findViewById(R.id.password);
        logIn = findViewById(R.id.logIn);
        email = findViewById(R.id.outlinedEmail);
        clave = findViewById(R.id.outlinedPassword);
    }

    /**
     * Method that checks if the user has already been authenticated before, if so it is not necessary to authenticate again
     */
    private void verifyAuthentication(String URL) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                if (!response.isEmpty()){
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(AuthActivity.this, "usuario o contraseña incorrecta", Toast.LENGTH_SHORT).show();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(AuthActivity.this, error.toString(), Toast.LENGTH_SHORT).show();

            }
        }){
            @Override
            protected Map<String, String> getParams () throws AuthFailureError{
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("usuario",mCorreo.getText().toString());
                parametros.put("password",mPassword.getText().toString());
                return parametros;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    /**
     * Method to restore the account if you have forgotten the password
     */
    /*
    private void restoredAccount() {
        olvidarTextLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText resetMail = new EditText(v.getContext());
                MaterialAlertDialogBuilder passwordResetDialog = new MaterialAlertDialogBuilder(v.getContext());
                passwordResetDialog.setTitle(getString(R.string.restablecer_contraseña));
                passwordResetDialog.setMessage(getString(R.string.link_restablecimiento));
                passwordResetDialog.setView(resetMail);
                passwordResetDialog.setPositiveButton(getString(R.string.aprobado), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String mail = resetMail.getText().toString();
                        fAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(AuthActivity.this, getString(R.string.link_enviado), Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(AuthActivity.this, getString(R.string.link_no_enviado) + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
                passwordResetDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                passwordResetDialog.create().show();
            }
        });
    }

    /**
     * Method for authentication


    private void logIn() {
        logIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String correo = mCorreo.getText().toString().trim();
                String password = mPassword.getText().toString().trim();

                if (TextUtils.isEmpty(correo)) {
                    email.setError(getString(R.string.campo_requerido));
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    clave.setError(getString(R.string.campo_requerido));
                    return;
                }

                if (password.length() < 6) {
                    clave.setError(getString(R.string.validacion_clave));
                    return;
                }

                fAuth.signInWithEmailAndPassword(correo, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        } else {
                            Toast.makeText(AuthActivity.this, "Error ! " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    /**
     * Method for handling error messages in the fields
     *
     * @param textInputLayouts this parameter will refer to the fields you want to manipulate errors
     */
    public void resetTextInputErrorsOnTextChanged(TextInputLayout... textInputLayouts) {
        for (final TextInputLayout inputLayout : textInputLayouts) {
            final TextInputEditText editText = (TextInputEditText) inputLayout.getEditText();
            if (editText != null) {
                editText.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after) {

                    }

                    @Override
                    public void onTextChanged(final CharSequence s, final int start, final int before, final int count) {
                    }

                    @Override
                    public void afterTextChanged(final Editable s) {
                        if (inputLayout.getError() != null) inputLayout.setError(null);
                    }
                });

                editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (!hasFocus) {
                            if (!TextUtils.isEmpty(editText.getText())) {
                                inputLayout.setError(null);
                            } else {
                                inputLayout.setError(getString(R.string.campo_requerido));
                            }
                        }
                    }
                });
            }
        }
    }
}