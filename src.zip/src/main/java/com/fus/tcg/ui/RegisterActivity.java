package com.fus.tcg.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.fus.tcg.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * Se depreca la calse
 */

@Deprecated
public class RegisterActivity extends AppCompatActivity {

    EditText mNombreCompleto, mCorreo, mPassword, mMovil;
    Button mRegistrarseBtn;
    TextView mCreateBtn;
    FirebaseAuth fAuth;
    private static final String TAG = RegisterActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mNombreCompleto = findViewById(R.id.NombreCompleto);
        mCorreo = findViewById(R.id.outlinedEmail);
        mPassword = findViewById(R.id.Password);
        mMovil = findViewById(R.id.Movil);
        mRegistrarseBtn = findViewById(R.id.logIn);
        mCreateBtn = findViewById(R.id.createText);

        fAuth = FirebaseAuth.getInstance();

        if(fAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }


        mRegistrarseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String correo = mCorreo.getText().toString().trim();
                String password = mPassword.getText().toString().trim();

                if (TextUtils.isEmpty(correo)) {
                    mCorreo.setError(" Se requiere el correo electronico ");
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    mPassword.setError(" Se requiere una contraseña ");
                    return;
                }

                if (password.length() < 6) {
                    mPassword.setError(" la contraseña debe ser mayor a 6 Caracteres ");
                    return;
                }

                //  Registro de usuarios en Firebase

                fAuth.createUserWithEmailAndPassword(correo, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            //envio link de verificacion

                            FirebaseUser fuser = fAuth.getCurrentUser();
                            fuser.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(RegisterActivity.this, "Correo de verificacion enviado.", Toast.LENGTH_SHORT).show();

                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG,"onFailure: Correo no enviado " + e.getMessage());

                                }
                            });

                            Toast.makeText(RegisterActivity.this, " Usuario Creado Satisfactoriamente.", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),MainActivity.class));

                        } else {
                             Toast.makeText(RegisterActivity.this,"Error ! " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }

                });

            }
        });

    mCreateBtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(), AuthActivity.class));
        }
    });
    }
}
