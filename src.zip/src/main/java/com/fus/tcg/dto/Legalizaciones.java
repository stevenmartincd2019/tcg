package com.fus.tcg.dto;

import java.io.Serializable;

import lombok.Data;


/**
 * DTO class for legalizations with use of lombok
 */
@Data
public class Legalizaciones implements Serializable {

    private String Nit;

    private String NombreProveedor;

    private String Telefono;

    private String Ciudad;

    private String TipoComprobante;

    private String FechaGasto;

    private String Consecutivo;

    private String Valor;

    private String Descripcion;

    private String Motivo;

    private String url;

    private String estado;

    public String getNit() {
        return Nit;
    }

    public void setNit(String nit) {
        Nit = nit;
    }

    public String getNombreProveedor() {
        return NombreProveedor;
    }

    public void setNombreProveedor(String nombreProveedor) {
        NombreProveedor = nombreProveedor;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }

    public String getCiudad() {
        return Ciudad;
    }

    public void setCiudad(String ciudad) {
        Ciudad = ciudad;
    }

    public String getTipoComprobante() {
        return TipoComprobante;
    }

    public void setTipoComprobante(String tipoComprobante) {
        TipoComprobante = tipoComprobante;
    }

    public String getFechaGasto() {
        return FechaGasto;
    }

    public void setFechaGasto(String fechaGasto) {
        FechaGasto = fechaGasto;
    }

    public String getConsecutivo() {
        return Consecutivo;
    }

    public void setConsecutivo(String consecutivo) {
        Consecutivo = consecutivo;
    }

    public String getValor() {
        return Valor;
    }

    public void setValor(String valor) {
        Valor = valor;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getMotivo() {
        return Motivo;
    }

    public void setMotivo(String motivo) {
        Motivo = motivo;
    }
}
